(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 5242:
/***/ ((module) => {

// Exports
module.exports = {
	"Container": "AdminLayout_Container__UsPZs",
	"Sidebar": "AdminLayout_Sidebar__eh2Me",
	"SidebarHeading": "AdminLayout_SidebarHeading__xsuwt",
	"SidebarInner": "AdminLayout_SidebarInner__D02jA",
	"SidebarLink": "AdminLayout_SidebarLink__oDHUF",
	"Active": "AdminLayout_Active__hsXJ2",
	"Main": "AdminLayout_Main__CFh9l"
};


/***/ }),

/***/ 1877:
/***/ ((module) => {

// Exports
module.exports = {
	"Footer": "Footer_Footer__wOtNb",
	"Logo": "Footer_Logo__cbetJ",
	"FooterListHeading": "Footer_FooterListHeading__lsnWR",
	"FooterList": "Footer_FooterList__jZFjl",
	"FooterLink": "Footer_FooterLink__lpRp_",
	"Top": "Footer_Top__Be32K"
};


/***/ }),

/***/ 8118:
/***/ ((module) => {

// Exports
module.exports = {
	"Main": "Layout_Main___3Mj_"
};


/***/ }),

/***/ 5780:
/***/ ((module) => {

// Exports
module.exports = {
	"Nav": "Nav_Nav__WC_B6",
	"Backdrop": "Nav_Backdrop__dJNZh",
	"OpenMenu": "Nav_OpenMenu__Irgm9",
	"NavMenuCloser": "Nav_NavMenuCloser___4wQR",
	"NavBrandLink": "Nav_NavBrandLink__1HoyK",
	"NavBrand": "Nav_NavBrand__oal0g",
	"NavBrandImgWrapper": "Nav_NavBrandImgWrapper__y2VF9",
	"NavBrandImg": "Nav_NavBrandImg___7c5W",
	"NavBrandText": "Nav_NavBrandText__WREjb",
	"NavInner": "Nav_NavInner__5oPxp",
	"Top": "Nav_Top__C3j1Y",
	"Bottom": "Nav_Bottom__jzJ0e",
	"NavSearch": "Nav_NavSearch__uG_6d",
	"NavSearchInput": "Nav_NavSearchInput__bTauY",
	"NavSearchButton": "Nav_NavSearchButton__USMi5",
	"TopNavItemsList": "Nav_TopNavItemsList__iq2Kt",
	"NavItemsList": "Nav_NavItemsList__ifDi8",
	"TopNavLink": "Nav_TopNavLink__UL7OV",
	"NavLink": "Nav_NavLink__Yg6FV",
	"Active": "Nav_Active__QxBdN",
	"NavMenuOpener": "Nav_NavMenuOpener__RJwSm",
	"Bar": "Nav_Bar__j_9lX",
	"NavItem": "Nav_NavItem__pUgiK"
};


/***/ }),

/***/ 4882:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "next/router"
const router_namespaceObject = require("next/router");
// EXTERNAL MODULE: ./components/Layout/Layout.module.css
var Layout_module = __webpack_require__(8118);
var Layout_module_default = /*#__PURE__*/__webpack_require__.n(Layout_module);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./components/Nav/Nav.module.css
var Nav_module = __webpack_require__(5780);
var Nav_module_default = /*#__PURE__*/__webpack_require__.n(Nav_module);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
;// CONCATENATED MODULE: ./components/Nav/Nav.js







const Nav = ()=>{
    const { 0: menuOpen , 1: setMenuOpen  } = (0,external_react_.useState)(false);
    const router = (0,router_namespaceObject.useRouter)();
    const openMenu = ()=>{
        if (menuOpen) return;
        setMenuOpen(true);
    };
    const closeMenu = ()=>{
        if (!menuOpen) return;
        setMenuOpen(false);
    };
    const topLinks = [
        {
            href: '/find-church',
            display: 'Find a Church'
        },
        {
            href: '/redress',
            display: 'Redress'
        },
        {
            href: '/#contact-us',
            display: 'Contact Us'
        },
        {
            href: '/clergy',
            display: 'Clergy Men'
        }, 
    ];
    const bottomLinks = [
        {
            href: '/events',
            display: 'Life Events'
        },
        {
            href: '/news-and-events',
            display: 'News & Events'
        },
        {
            href: '/about',
            display: 'About the Church'
        },
        {
            href: '/women',
            display: 'Women[M.U & W.G]'
        },
        {
            href: '/meet-bishop',
            display: 'Meet the Bishop'
        }, 
    ];
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
        className: [
            (Nav_module_default()).Nav,
            menuOpen ? (Nav_module_default()).OpenMenu : ''
        ].join(' '),
        children: [
            menuOpen && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Nav_module_default()).Backdrop,
                onClick: closeMenu
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                href: "/",
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    className: (Nav_module_default()).NavBrandLink,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Nav_module_default()).NavBrand,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Nav_module_default()).NavBrandImgWrapper,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                    className: (Nav_module_default()).NavBrandImg,
                                    alt: "Church Logo",
                                    src: "/images/diocese-logo.png",
                                    height: "60px",
                                    width: "60px"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Nav_module_default()).NavBrandText,
                                children: [
                                    "DIOCESE OF ONDO",
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: "[Anglican Communion]"
                                    })
                                ]
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Nav_module_default()).NavInner,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Nav_module_default()).NavMenuCloser,
                        onClick: closeMenu
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Nav_module_default()).Top,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                            className: (Nav_module_default()).TopNavItemsList,
                            children: topLinks.map(({ href , display  })=>{
                                const isActive = router.pathname === href;
                                return(/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: (Nav_module_default()).TopNavItem,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: href,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: [
                                                (Nav_module_default()).TopNavLink,
                                                isActive ? (Nav_module_default()).Active : ''
                                            ].join(' '),
                                            children: display
                                        })
                                    })
                                }, display));
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Nav_module_default()).Bottom,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Nav_module_default()).NavSearch,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        className: (Nav_module_default()).NavSearchInput,
                                        placeholder: "Search"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: (Nav_module_default()).NavSearchButton,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaSearch, {
                                            size: "1.3em",
                                            className: (Nav_module_default()).NavSearchIcon,
                                            alt: "Search Icon"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                className: (Nav_module_default()).NavItemsList,
                                children: bottomLinks.map(({ href , display  })=>{
                                    const isActive = router.pathname === href;
                                    return(/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Nav_module_default()).NavItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            onClick: ()=>setMenuOpen(false)
                                            ,
                                            href: href,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: [
                                                    (Nav_module_default()).NavLink,
                                                    isActive ? (Nav_module_default()).Active : ''
                                                ].join(' '),
                                                children: display
                                            })
                                        })
                                    }, display));
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Nav_module_default()).NavMenuOpener,
                onClick: openMenu,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Nav_module_default()).Bar
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Nav_module_default()).Bar
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Nav_module_default()).Bar
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const Nav_Nav = (Nav);

// EXTERNAL MODULE: ./components/Footer/Footer.module.css
var Footer_module = __webpack_require__(1877);
var Footer_module_default = /*#__PURE__*/__webpack_require__.n(Footer_module);
;// CONCATENATED MODULE: ./components/Footer/Footer.js




const footer = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: (Footer_module_default()).Footer,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                    className: (Footer_module_default()).Logo,
                    alt: "Church Logo",
                    src: "/images/diocese-logo.png",
                    height: "60px",
                    width: "60px"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Footer_module_default()).Top,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Footer_module_default()).FooterListWrapper,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: (Footer_module_default()).FooterListHeading,
                                children: "News"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: (Footer_module_default()).FooterList,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Events"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Blogs"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Synod"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Programs"
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Footer_module_default()).FooterListWrapper,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: (Footer_module_default()).FooterListHeading,
                                children: "Watch"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: (Footer_module_default()).FooterList,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Youtube"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Radio"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Podcast"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Gallery"
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Footer_module_default()).FooterListWrapper,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: (Footer_module_default()).FooterListHeading,
                                children: "Give"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: (Footer_module_default()).FooterList,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Payable Accounts"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Donate"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Dues"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Accounting System"
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Footer_module_default()).FooterListWrapper,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: (Footer_module_default()).FooterListHeading,
                                children: "Ministries"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: (Footer_module_default()).FooterList,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Youth"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Children"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Women"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Men"
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Footer_module_default()).FooterListWrapper,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: (Footer_module_default()).FooterListHeading,
                                children: "Churches"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: (Footer_module_default()).FooterList,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Archdeaconries"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Archdeacons"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Parish Churches"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Footer_module_default()).FooterListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Footer_module_default()).FooterLink,
                                                children: "Priests"
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Footer_module_default()).Bottom,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: "Contact us"
                })
            })
        ]
    }));
};
/* harmony default export */ const Footer = (footer);

;// CONCATENATED MODULE: ./components/Layout/Layout.js




const layout = ({ children  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Nav_Nav, {
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                className: (Layout_module_default()).Main,
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Footer, {
            })
        ]
    }));
};
/* harmony default export */ const Layout = (layout);

// EXTERNAL MODULE: ./components/AdminLayout/AdminLayout.module.css
var AdminLayout_module = __webpack_require__(5242);
var AdminLayout_module_default = /*#__PURE__*/__webpack_require__.n(AdminLayout_module);
;// CONCATENATED MODULE: ./components/AdminLayout/AdminLayout.js




const Sidebar = ()=>{
    const router = (0,router_namespaceObject.useRouter)();
    const pathNames = [
        'home',
        'news',
        'events',
        'women',
        'gallery',
        'radio',
        'churches',
        'priests',
        'members'
    ];
    const capitalize = ([firstLetter, ...rest])=>firstLetter.toUpperCase() + rest.join('')
    ;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
        className: (AdminLayout_module_default()).Sidebar,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: (AdminLayout_module_default()).SidebarHeading,
                children: "WELCOME ADMIN"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: (AdminLayout_module_default()).SidebarInner,
                children: pathNames.map((pathName)=>{
                    const isActive = router.pathname === '/admin/' + pathName;
                    return(/*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: (AdminLayout_module_default()).SidebarItem,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: pathName,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: [
                                    (AdminLayout_module_default()).SidebarLink,
                                    isActive ? (AdminLayout_module_default()).Active : ''
                                ].join(' '),
                                children: capitalize(pathName).replace(' ', '-')
                            })
                        })
                    }, pathName));
                })
            })
        ]
    }));
};
const AdminLayout = ({ children  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (AdminLayout_module_default()).Container,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Sidebar, {
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                className: (AdminLayout_module_default()).Main,
                children: children
            })
        ]
    }));
};
/* harmony default export */ const AdminLayout_AdminLayout = (AdminLayout);

;// CONCATENATED MODULE: external "react-icons"
const external_react_icons_namespaceObject = require("react-icons");
;// CONCATENATED MODULE: ./pages/_app.js






function MyApp({ Component , pageProps  }) {
    const router = (0,router_namespaceObject.useRouter)();
    let page;
    if (router.pathname.includes('/admin')) {
        page = /*#__PURE__*/ jsx_runtime_.jsx(AdminLayout_AdminLayout, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            })
        });
    } else {
        page = /*#__PURE__*/ jsx_runtime_.jsx(Layout, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            })
        });
    }
    return(/*#__PURE__*/ jsx_runtime_.jsx(external_react_icons_namespaceObject.IconContext.Provider, {
        value: {
            color: 'var(--pri)'
        },
        children: page
    }));
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,664,675], () => (__webpack_exec__(4882)));
module.exports = __webpack_exports__;

})();