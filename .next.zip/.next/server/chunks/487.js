exports.id = 487;
exports.ids = [487];
exports.modules = {

/***/ 7667:
/***/ ((module) => {

// Exports
module.exports = {
	"Container": "UploadImage_Container__p8hRu",
	"Image": "UploadImage_Image__F_Lgj",
	"Input": "UploadImage_Input__idXzn",
	"PlusIcon": "UploadImage_PlusIcon__9JwdV",
	"AddImage": "UploadImage_AddImage___fc33"
};


/***/ }),

/***/ 5487:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ UploadImage_UploadImage)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/UploadImage/UploadImage.module.css
var UploadImage_module = __webpack_require__(7667);
var UploadImage_module_default = /*#__PURE__*/__webpack_require__.n(UploadImage_module);
;// CONCATENATED MODULE: ./components/Image/Image.js

const Image = ({ file , alt , ...rest })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("img", {
        src: URL.createObjectURL(file),
        alt: alt,
        ...rest
    }));
};
/* harmony default export */ const Image_Image = (Image);

// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
;// CONCATENATED MODULE: ./components/UploadImage/UploadImage.js





const UploadImage = ({ file , setFile , name: name1 , className  })=>{
    const { 0: unsupported , 1: setUnsupported  } = (0,external_react_.useState)(false);
    const fileInput = (0,external_react_.useRef)();
    const chooseImage = ()=>fileInput.current.click()
    ;
    const FILE_TYPES = [
        'png',
        'jpg',
        'jpeg'
    ];
    const onChange = (e)=>{
        const selectedFile = e.target.files[0];
        if (!setUnsupported) return;
        const { name  } = selectedFile;
        const ext = name.slice((name.lastIndexOf(".") - 1 >>> 0) + 2);
        if (!FILE_TYPES.includes(ext)) {
            setUnsupported(true);
            return;
        }
        setFile(selectedFile);
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: [
            (UploadImage_module_default()).Container,
            className
        ].join(' '),
        onClick: chooseImage,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                ref: fileInput,
                className: (UploadImage_module_default()).Input,
                type: "file",
                onChange: onChange,
                accept: FILE_TYPES.map((type)=>'.' + type
                ).join(', '),
                name: name1
            }),
            file ? /*#__PURE__*/ jsx_runtime_.jsx(Image_Image, {
                file: file,
                alt: file.filename,
                className: (UploadImage_module_default()).Image
            }) : unsupported ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: "Unsupported file type please upload a png, jpg or jpeg file"
            }) : /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaPlusCircle, {
                className: (UploadImage_module_default()).PlusIcon,
                size: "50px",
                color: "var(--pri)"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (UploadImage_module_default()).AddImage,
                children: [
                    file ? 'Change ' : 'Add ',
                    "Image"
                ]
            })
        ]
    }));
};
/* harmony default export */ const UploadImage_UploadImage = (UploadImage);


/***/ })

};
;