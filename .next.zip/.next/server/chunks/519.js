exports.id = 519;
exports.ids = [519];
exports.modules = {

/***/ 6093:
/***/ ((module) => {

// Exports
module.exports = {
	"Container": "AutoGrowingTextarea_Container__MlB2_",
	"Stacked": "AutoGrowingTextarea_Stacked__ERq63"
};


/***/ }),

/***/ 1519:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _AutoGrowingTextarea_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6093);
/* harmony import */ var _AutoGrowingTextarea_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_AutoGrowingTextarea_module_css__WEBPACK_IMPORTED_MODULE_2__);



const AutoGrowingTextarea = ({ value ='' , onChange , placeholder ='' , className ='' , textareaClassName =''  })=>{
    const textarea = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (textarea.current) {
            if (!value) {
                textarea.current.value = '';
            } else {
                textarea.current.value = value;
            }
        }
    }, [
        value
    ]);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: [
            (_AutoGrowingTextarea_module_css__WEBPACK_IMPORTED_MODULE_2___default().Container),
            (_AutoGrowingTextarea_module_css__WEBPACK_IMPORTED_MODULE_2___default().Stacked),
            className
        ].join(' '),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
            ref: textarea,
            placeholder: placeholder,
            className: [
                (_AutoGrowingTextarea_module_css__WEBPACK_IMPORTED_MODULE_2___default().Textarea),
                textareaClassName
            ].join(' '),
            value: value,
            onChange: (e)=>{
                e.target.parentNode.dataset.value = e.target.value;
                if (onChange) onChange(e);
            }
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AutoGrowingTextarea);


/***/ })

};
;