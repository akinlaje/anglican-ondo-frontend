exports.id = 98;
exports.ids = [98];
exports.modules = {

/***/ 590:
/***/ ((module) => {

// Exports
module.exports = {
	"Container": "Calendar_Container__PH0Cm",
	"Nav": "Calendar_Nav__txRs8",
	"Days": "Calendar_Days__FoTKu",
	"Day": "Calendar_Day__zrYXm",
	"WeekDay": "Calendar_WeekDay__eXw0c",
	"NotInCurrentMonth": "Calendar_NotInCurrentMonth__5hsGQ",
	"Selected": "Calendar_Selected__KJHqL"
};


/***/ }),

/***/ 4625:
/***/ ((module) => {

// Exports
module.exports = {
	"Container": "DatePicker_Container__1qo_J",
	"Label": "DatePicker_Label__8sxDa",
	"Input": "DatePicker_Input__vDquN",
	"Active": "DatePicker_Active__2BQIF",
	"Calendar": "DatePicker_Calendar__knm5r"
};


/***/ }),

/***/ 9529:
/***/ ((module) => {

// Exports
module.exports = {
	"Container": "TimePicker_Container__kbiI9",
	"InputWrapper": "TimePicker_InputWrapper__8kAWH",
	"Input": "TimePicker_Input__OLewl",
	"Colon": "TimePicker_Colon__rccxA",
	"Selectbox": "TimePicker_Selectbox__4kY1v",
	"Open": "TimePicker_Open__nZtqC",
	"SelectboxDisplay": "TimePicker_SelectboxDisplay__CfHsg",
	"SelectboxArrowDown": "TimePicker_SelectboxArrowDown__wVCPb",
	"SelectboxDropdown": "TimePicker_SelectboxDropdown__wec60",
	"SelectboxOption": "TimePicker_SelectboxOption__muBck",
	"Selected": "TimePicker_Selected__0ivae"
};


/***/ }),

/***/ 1342:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ DatePicker_DatePicker)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/DatePicker/DatePicker.module.css
var DatePicker_module = __webpack_require__(4625);
var DatePicker_module_default = /*#__PURE__*/__webpack_require__.n(DatePicker_module);
// EXTERNAL MODULE: ./components/Calendar/Calendar.module.css
var Calendar_module = __webpack_require__(590);
var Calendar_module_default = /*#__PURE__*/__webpack_require__.n(Calendar_module);
// EXTERNAL MODULE: external "react-icons/gr"
var gr_ = __webpack_require__(8547);
// EXTERNAL MODULE: ./utils.js
var utils = __webpack_require__(1313);
;// CONCATENATED MODULE: ./components/Calendar/Calendar.js





const Calendar = ({ date =new Date() , setDate , initialDate , className  })=>{
    const { 0: currentDate , 1: setCurrentDate  } = (0,external_react_.useState)(date);
    // const currentDayOfWeek = currentDate.getDay();
    // const currentDayOfMonth = currentDate.getDate();
    const currentMonth = currentDate.getMonth();
    const currentYear = currentDate.getFullYear();
    (0,external_react_.useEffect)(()=>{
        setCurrentDate(date);
    }, [
        date
    ]);
    const isLeapYear = (year)=>!(year & 3 || !(year % 25) && year & 15)
    ;
    const WEEK_DAYS = [
        'Sunday',
        'Monday',
        'Tuesday',
        'Wednesday',
        'Thursday',
        'Friday',
        'Saturday'
    ];
    const MONTHS = [
        'January',
        'Febuary',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'
    ].map((name, i)=>{
        let numDays = 31;
        if ([
            3,
            5,
            8,
            10
        ].includes(i)) numDays = 30;
        if (i === 1) numDays = isLeapYear(currentYear) ? 29 : 28;
        return {
            name,
            numDays
        };
    });
    const getMonthDaysNum = (monthIndex)=>MONTHS[monthIndex].numDays
    ;
    const getPrevMonth = (monthIndex)=>monthIndex === 0 ? 11 : monthIndex - 1
    ;
    const getNextMonth = (monthIndex)=>monthIndex === 11 ? 0 : monthIndex + 1
    ;
    const next = ()=>{
        let year = currentYear;
        if (currentMonth === 11) year++;
        const nextMonth = getNextMonth(currentMonth);
        setCurrentDate(new Date(year, nextMonth));
    };
    const prev = ()=>{
        let year = currentYear;
        if (currentMonth === 0) year--;
        const prevMonth = getPrevMonth(currentMonth);
        setCurrentDate(new Date(year, prevMonth));
    };
    const firstWeekDayOfMonth = new Date(currentYear, currentMonth, 0).getDay();
    const days = [
        ...Array(35)
    ].map((_, i)=>{
        let calendarDate, isInCurrentMonth, isInPrevMonth, isInNextMonth, selected;
        if (firstWeekDayOfMonth < i) {
            const currentMonthNumDays = getMonthDaysNum(currentMonth);
            if (i > currentMonthNumDays + firstWeekDayOfMonth) {
                calendarDate = i - (currentMonthNumDays + firstWeekDayOfMonth);
                isInNextMonth = true;
            } else {
                calendarDate = i - firstWeekDayOfMonth;
                isInCurrentMonth = true;
            }
        } else {
            const prevMonthIndex = getPrevMonth(currentMonth);
            calendarDate = getMonthDaysNum(prevMonthIndex) - firstWeekDayOfMonth + i;
            isInPrevMonth = true;
        }
        if (date && (0,utils/* isValidDate */.q)(date) && date.getDate() === calendarDate) {
            selected = date.getMonth() === currentMonth ? isInCurrentMonth : date.getMonth() === getPrevMonth(currentMonth) ? isInPrevMonth : date.getMonth() === getNextMonth(currentMonth) ? isInNextMonth : false // next month
            ;
        }
        return {
            calendarDate,
            isInCurrentMonth,
            isInNextMonth,
            isInPrevMonth,
            selected
        };
    });
    const currentMonthName = MONTHS[currentMonth].name;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: [
            (Calendar_module_default()).Container,
            className
        ].join(' '),
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Calendar_module_default()).Nav,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(gr_.GrFormPrevious, {
                        size: "1.5em",
                        className: (Calendar_module_default()).Icon,
                        onClick: prev
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: currentMonthName
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: currentYear
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(gr_.GrFormNext, {
                        size: "1.5em",
                        className: (Calendar_module_default()).Icon,
                        onClick: next
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Calendar_module_default()).Days,
                children: [
                    WEEK_DAYS.map((day)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (Calendar_module_default()).WeekDay,
                            children: day.substring(0, 2)
                        }, day)
                    ),
                    days.map((day, i)=>{
                        const { isInCurrentMonth , calendarDate , isInPrevMonth , isInNextMonth , selected  } = day;
                        const onClick = ()=>{
                            const month = isInCurrentMonth ? currentMonth : isInPrevMonth ? getPrevMonth(currentMonth) : getNextMonth(currentMonth);
                            const year = currentMonth === 11 && isInNextMonth ? currentYear + 1 : currentMonth === 0 && isInPrevMonth ? currentYear - 1 : currentYear;
                            const dt = new Date(year, month, calendarDate);
                            // console.log(dt.getMonth);
                            setDate(dt);
                        };
                        return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: [
                                (Calendar_module_default()).Day,
                                !isInCurrentMonth ? (Calendar_module_default()).NotInCurrentMonth : '',
                                selected ? (Calendar_module_default()).Selected : ''
                            ].join(' '),
                            onClick: onClick,
                            children: calendarDate
                        }, i));
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const Calendar_Calendar = (Calendar);

// EXTERNAL MODULE: ./hoc/HandleClickOutside.js
var HandleClickOutside = __webpack_require__(4374);
// EXTERNAL MODULE: external "luxon"
var external_luxon_ = __webpack_require__(2748);
;// CONCATENATED MODULE: ./components/DatePicker/DatePicker.js







const DatePicker = ({ date: date1 , setDate , className , label  })=>{
    const { 0: open , 1: setOpen  } = (0,external_react_.useState)(false);
    const { 0: inputDateValid , 1: setInputDateValid  } = (0,external_react_.useState)((0,utils/* isValidDate */.q)(date1));
    const { 0: value , 1: setValue  } = (0,external_react_.useState)(inputDateValid ? date1 : '');
    const ref = (0,external_react_.useRef)();
    const FORMAT = 'dd/MM/yyyy';
    const LOCALE = 'en-GB';
    const closeCalendar = ()=>setOpen(false)
    ;
    const openCalendar = ()=>setOpen(true)
    ;
    const parseDate = (str, format, locale)=>{
        const dt = external_luxon_.DateTime.fromFormat(str, format, locale);
        const parsed = dt.toJSDate();
        if ((0,utils/* isValidDate */.q)(parsed)) {
            return parsed;
        }
        return undefined;
    };
    const formatDate = (date, format, locale)=>{
        return external_luxon_.DateTime.fromJSDate(date).setLocale(locale).toFormat(format);
    };
    const pad = (dateString)=>{
        let [day = '', month = '', year = ''] = dateString.split('/');
        if (day.length === 1) day = day.padStart(2, '0');
        if (month.length === 1) month = month = month.padStart(2, '0');
        if (year.length === 2) year = year.padStart(4, '20');
        return [
            day,
            month,
            year
        ].join('/');
    };
    const onChange = (e)=>{
        let newDate = e.target.value;
        setValue(newDate);
        // pad day, month and year parts of the string before parsing
        newDate = pad(newDate);
        const parsed = parseDate(newDate, FORMAT, LOCALE);
        // console.log(parsed);
        if (parsed) {
            setInputDateValid(true);
            setDate(parsed);
        }
    };
    const onBlur = ()=>{
        if (inputDateValid) setValue(formatDate(date1, FORMAT, LOCALE));
    };
    const setCalendarDate = (date)=>{
        const formatted = formatDate(date, FORMAT, LOCALE);
        setValue(formatted);
        setDate(date);
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        ref: ref,
        className: [
            (DatePicker_module_default()).Container,
            className
        ].join(' '),
        onClick: openCalendar,
        children: [
            label && /*#__PURE__*/ jsx_runtime_.jsx("label", {
                htmlFor: "date",
                children: label
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                className: (DatePicker_module_default()).Input,
                placeholder: FORMAT.toUpperCase(),
                value: value,
                onChange: onChange,
                onBlur: onBlur,
                name: "date"
            }),
            open && /*#__PURE__*/ jsx_runtime_.jsx(HandleClickOutside/* default */.Z, {
                container: ref,
                onOutsideClick: closeCalendar,
                children: /*#__PURE__*/ jsx_runtime_.jsx(Calendar_Calendar, {
                    className: (DatePicker_module_default()).Calendar,
                    date: date1,
                    setDate: setCalendarDate
                })
            })
        ]
    }));
};
/* harmony default export */ const DatePicker_DatePicker = (DatePicker);


/***/ }),

/***/ 6599:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ TimePicker_TimePicker)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/TimePicker/TimePicker.module.css
var TimePicker_module = __webpack_require__(9529);
var TimePicker_module_default = /*#__PURE__*/__webpack_require__.n(TimePicker_module);
// EXTERNAL MODULE: ./hoc/HandleClickOutside.js
var HandleClickOutside = __webpack_require__(4374);
// EXTERNAL MODULE: external "react-icons/md"
var md_ = __webpack_require__(4041);
;// CONCATENATED MODULE: ./components/Selectbox/Selectbox.js




const Selectbox = ({ options , value , onChange , styles ={
} , placeholder  })=>{
    const { 0: open , 1: setOpen  } = (0,external_react_.useState)(false);
    const optionListRef = (0,external_react_.useRef)();
    const openDropdown = ()=>setOpen(true)
    ;
    const closeDropdown = ()=>setOpen(false)
    ;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: [
            styles.Selectbox,
            open ? styles.Open : ''
        ].join(' '),
        onClick: openDropdown,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: styles.SelectboxDisplay,
                children: [
                    (value === null || value === void 0 ? void 0 : value.id) ? value.display : placeholder ? placeholder : 'Select',
                    /*#__PURE__*/ jsx_runtime_.jsx(md_.MdArrowDropDown, {
                        size: "1.5em",
                        style: {
                            transformOrigin: '50% 50%',
                            transform: open ? 'rotateZ(180deg)' : 'rotateZ(0deg)',
                            transition: 'transform ease-out 300ms'
                        },
                        className: styles.SelectboxArrowDown
                    })
                ]
            }),
            open && /*#__PURE__*/ jsx_runtime_.jsx(HandleClickOutside/* default */.Z, {
                container: optionListRef,
                onOutsideClick: closeDropdown,
                children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                    ref: optionListRef,
                    className: styles.SelectboxDropdown,
                    onClick: (e)=>e.stopPropagation()
                    ,
                    children: options.map((option)=>{
                        const { display , id  } = option;
                        const clicked = ()=>{
                            onChange(option);
                            closeDropdown();
                        };
                        return(/*#__PURE__*/ jsx_runtime_.jsx("li", {
                            onClick: clicked,
                            className: [
                                styles.SelectboxOption,
                                value.id === id ? styles.Selected : ''
                            ].join(' '),
                            children: display
                        }, id));
                    })
                })
            })
        ]
    }));
};
/* harmony default export */ const Selectbox_Selectbox = (Selectbox);

;// CONCATENATED MODULE: ./components/TimePicker/TimePicker.js




// import { DateTime } from 'luxon';
const TimePicker = ({ value: value1 , onChange: onChange1 , className , label , setTime  })=>{
    const { 0: refs  } = (0,external_react_.useState)([
        /*#__PURE__*/ (0,external_react_.createRef)(),
        /*#__PURE__*/ (0,external_react_.createRef)()
    ]);
    const { 0: timeValues1 , 1: setTimeValues  } = (0,external_react_.useState)(Array(2).fill(''));
    const { 0: timePeriod , 1: setTimePeriod  } = (0,external_react_.useState)({
        display: 'AM',
        id: 'am'
    });
    const ALLOWED_KEYS = [
        '1',
        '2',
        '3',
        '4',
        '5',
        '6',
        '7',
        '8',
        '9',
        '0'
    ];
    const placeholders = [
        'hh',
        'mm'
    ];
    (0,external_react_.useEffect)(()=>{
        let [hour, minute] = timeValues1;
        if (!hour.length || !minute.length || !(timePeriod === null || timePeriod === void 0 ? void 0 : timePeriod.id)) return;
        if (timePeriod.id === 'pm') hour = Number(hour) + 12;
        // const date = DateTime.fromObject({
        // 	hour,
        // 	minute
        // }).toJSDate();
        // console.log(date);
        setTime({
            hour,
            minute
        });
    }, [
        timeValues1,
        setTime,
        timePeriod
    ]);
    const setTimeValue = (i, value)=>{
        let valid = false;
        if (i === 0) valid = Number(value) < 13;
        if (i === 1) valid = Number(value) < 60;
        if (!valid) return;
        setTimeValues((timeValues)=>timeValues.map((n, index)=>i === index ? value : n
            )
        );
    };
    const deleteStringCharAtIndex = (str, i)=>{
        const tmp = str.split('');
        tmp.splice(i, 1);
        return tmp.join('');
    };
    const inputs = refs.map((n, i)=>{
        const onKeyDown = (e)=>{
            const { target: { selectionStart  } , key  } = e;
            // console.log('Value: ', value, 'Key: ', key);
            if (key === 'Backspace') {
                const caretPosition = selectionStart;
                if (caretPosition > 0 && timeValues1[i].length > 0) {
                    setTimeValue(i, deleteStringCharAtIndex(timeValues1[i], caretPosition - 1));
                }
                if (caretPosition === 0 && i > 0) {
                    refs[i - 1].current.focus();
                } else return;
            } else {
                if (!ALLOWED_KEYS.includes(key)) return;
                // if there is already a value in this field
                // and this is not the last field focus the next field
                if (timeValues1[i].length < 2) {
                    setTimeValue(i, timeValues1[i] + key);
                } else if (timeValues1[i].length === 2 && i === 0) {
                    setTimeValue(i + 1, key);
                    refs[i + 1].current.focus();
                    return;
                }
            }
        };
        const onChange = (e)=>{
            const { value  } = e.target;
            const char = value[value.length - 1];
            // console.log(value, ALLOWED_KEYS.includes(char), timeValues[i].length > 1);
            if (char && !ALLOWED_KEYS.includes(char)) return;
            if (timeValues1[i].length > 1) {
                // use the next field if this input already has a value 
                // and is'nt the last input
                e.preventDefault();
            }
        };
        return(/*#__PURE__*/ jsx_runtime_.jsx("input", {
            ref: refs[i],
            value: timeValues1[i],
            onChange: onChange,
            onKeyDown: onKeyDown,
            className: [
                (TimePicker_module_default()).Input,
                n ? (TimePicker_module_default()).Filled : ''
            ].join(' '),
            autoFocus: i === 0,
            placeholder: placeholders[i]
        }, i));
    });
    inputs.splice(1, 0, /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (TimePicker_module_default()).Colon,
        children: ":"
    }, "colon"));
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: [
            (TimePicker_module_default()).Container,
            className
        ].join(' '),
        children: [
            !value1 && label ? /*#__PURE__*/ jsx_runtime_.jsx("span", {
                children: label
            }) : 'Choose Time',
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (TimePicker_module_default()).InputWrapper,
                children: [
                    inputs,
                    /*#__PURE__*/ jsx_runtime_.jsx(Selectbox_Selectbox, {
                        options: [
                            {
                                display: 'AM',
                                id: 'am'
                            },
                            {
                                display: 'PM',
                                id: 'pm'
                            }, 
                        ],
                        value: timePeriod,
                        onChange: (v)=>setTimePeriod(v)
                        ,
                        styles: (TimePicker_module_default())
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const TimePicker_TimePicker = (TimePicker);


/***/ }),

/***/ 4374:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const HandleClickOutside = ({ onOutsideClick , onInsideClick , container , children  })=>{
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        // console.log(container);
        const clickOutsideHandler = (event)=>{
            event.stopPropagation();
            if (onOutsideClick && container.current && !container.current.contains(event.target)) {
                // console.log(event.target);
                onOutsideClick();
            } else if (onInsideClick) {
                onInsideClick();
            }
        };
        document.addEventListener('click', clickOutsideHandler);
        return ()=>document.removeEventListener('click', clickOutsideHandler)
        ;
    }, [
        onOutsideClick,
        container,
        onInsideClick
    ]);
    return children;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HandleClickOutside);


/***/ }),

/***/ 1313:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ JSONToFormData),
/* harmony export */   "q": () => (/* binding */ isValidDate)
/* harmony export */ });
const JSONToFormData = (json)=>{
    const formData = new FormData();
    for(const key in json){
        formData.append(key, json[key]);
    }
    return formData;
};
const isValidDate = (d)=>{
    let valid = false;
    if (Object.prototype.toString.call(d) === '[object Date]') {
        if (!isNaN(d.getTime())) {
            valid = true;
        }
    }
    return valid;
};


/***/ })

};
;